package com.georg777.encdec;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private ArrayList<String> List = new ArrayList<>();
	
	private LinearLayout Linear;
	private EditText EditText;
	private Button EncodeButton;
	private Button DecodeButton;
	private LinearLayout ButtonLinear;
	private CheckBox HEXCheckBox;
	private CheckBox BinaryCheckBox;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		Linear = findViewById(R.id.Linear);
		EditText = findViewById(R.id.EditText);
		EncodeButton = findViewById(R.id.EncodeButton);
		DecodeButton = findViewById(R.id.DecodeButton);
		ButtonLinear = findViewById(R.id.ButtonLinear);
		HEXCheckBox = findViewById(R.id.HEXCheckBox);
		BinaryCheckBox = findViewById(R.id.BinaryCheckBox);
		
		EncodeButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				String text = EditText.getText().toString();
				String encoded = "";
				if (HEXCheckBox.isChecked()) {
					    StringBuilder hexString = new StringBuilder();
					    for (byte b : text.getBytes()) hexString.append(String.format("%02X", b));
					    encoded = hexString.toString();
				} else if (BinaryCheckBox.isChecked()) {
					    StringBuilder binaryString = new StringBuilder();
					    for (byte b : text.getBytes()) binaryString.append(String.format("%8s", Integer.toBinaryString(b & 0xFF)).replace(' ', '0')).append(" ");
					    encoded = binaryString.toString().trim();
				} else {
					    encoded = android.util.Base64.encodeToString(text.getBytes(), android.util.Base64.DEFAULT);
				}
				EditText.setText(encoded);
			}
		});
		
		DecodeButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				String text = EditText.getText().toString();
				String decoded = text;
				try {
					    if (HEXCheckBox.isChecked()) {
						        byte[] data = new byte[text.length() / 2];
						        for (int i = 0; i < text.length(); i += 2) {
							            data[i / 2] = (byte) ((Character.digit(text.charAt(i), 16) << 4) + Character.digit(text.charAt(i + 1), 16));
							        }
						        decoded = new String(data);
						    } else if (BinaryCheckBox.isChecked()) {
						        text = text.replace(" ", "");
						        byte[] data = new byte[text.length() / 8];
						        for (int i = 0; i < text.length(); i += 8) {
							            data[i / 8] = (byte) Integer.parseInt(text.substring(i, i + 8), 2);
							        }
						        decoded = new String(data);
						    } else {
						        decoded = new String(android.util.Base64.decode(text, android.util.Base64.DEFAULT));
						    }
				} catch (Exception e) { }
				EditText.setText(decoded);
			}
		});
		
		HEXCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (BinaryCheckBox.isChecked()) {
					HEXCheckBox.setChecked(false);
				}
			}
		});
		
		BinaryCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (HEXCheckBox.isChecked()) {
					BinaryCheckBox.setChecked(false);
				}
			}
		});
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
	}
	
}